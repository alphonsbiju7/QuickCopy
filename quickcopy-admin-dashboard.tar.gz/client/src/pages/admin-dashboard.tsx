import { useEffect } from "react";
import AdminSidebar from "@/components/admin-sidebar";
import AdminHeader from "@/components/admin-header";
import StatsCards from "@/components/stats-cards";
import FileTable from "@/components/file-table";
import DownloadModal from "@/components/download-modal";
import BatchDownloadModal from "@/components/batch-download-modal";
import { useQuery } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";

export default function AdminDashboard() {
  const { data: files = [], refetch } = useQuery({
    queryKey: ["/api/files"],
  });

  const { data: stats = {} } = useQuery({
    queryKey: ["/api/stats"],
  });

  // Create demo files on first load
  useEffect(() => {
    const createDemoFiles = async () => {
      if (files.length === 0) {
        try {
          await apiRequest("POST", "/api/files/demo", {});
          refetch();
        } catch (error) {
          console.error("Failed to create demo files:", error);
        }
      }
    };
    createDemoFiles();
  }, [files.length, refetch]);

  return (
    <div className="min-h-screen flex bg-slate-50" data-testid="admin-dashboard">
      {/* Desktop sidebar - hidden on mobile */}
      <div className="hidden lg:block">
        <AdminSidebar />
      </div>
      
      {/* Main content area */}
      <main className="flex-1 flex flex-col overflow-hidden w-full lg:w-auto">
        <AdminHeader />
        <div className="flex-1 overflow-auto p-3 sm:p-4 lg:p-6">
          <StatsCards stats={stats} />
          <FileTable files={files} />
        </div>
      </main>
      
      <DownloadModal />
      <BatchDownloadModal />
    </div>
  );
}